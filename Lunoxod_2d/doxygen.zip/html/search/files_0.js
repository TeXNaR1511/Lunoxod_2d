var searchData=
[
  ['app_2eaxaml_2ecs_0',['App.axaml.cs',['../_app_8axaml_8cs.html',1,'']]]
];
